./cmake-build-debug/file-client-tcp students.mimuw.edu.pl 2137 proc_server.c &
./cmake-build-debug/file-client-tcp students.mimuw.edu.pl 2137 preforked_server.c &
./cmake-build-debug/file-client-tcp students.mimuw.edu.pl 2137 reuse_server.c &

wait
